# DEE_AMS_Project
 Data Engineering Project

Group: 2. Arbeitsmarkt ODÖ Personen
Authors: Marlis Tiefengraber, Lorenz Duelli, Oliver Miniszewski, Lorenz Flich, Christopher Tolan & Maja Cvetkovska

The data acquisition, the analysis and the hypotheses can be found in the Jupyter Notebook file *prj01.ipynb*.

Before executing the notebook, the files inside the following Zip Files have to be extracted into the same directory:
1. Bestand_SC_Alter_Berufswunsch_RGS.zip
2. clean_data.zip
3. merged_data.zip

This is because the files are too large for GitHub.